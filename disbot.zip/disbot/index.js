const discord = require('discord.js');
const client = new discord.Client();

client.once('ready', () => {
	console.log('Ready!');
});

client.login('OTQ2MDE3MTIyNDE1NDE5NDQy.YhYlGg._7KGvVRRdZJjnFlm-vqFCinFMm8');
